# EXERCÍCIO 16.05: Bigramas e Similaridade de Jaccard

#------------------------------------------------------------
# Preliminar: obtendo a lista de bigramas de uma string
palavra = "banana"

bigramas = []
for i in range(len(palavra)-1): # do primeiro ao penultimo caractere
    bg = palavra[i:i+2]         # capturar o bigrama da posição i,i+1
    bigramas.append(bg)         # inserir o bigrama na lista

print('- Preliminar:')
print(f"os bigramas de {palavra} são: {bigramas}\n\n")

#------------------------------------------------------------
# PARTE 1: gerar bigramas para diversas palavras
# (basta adaptar o código anterior)
#------------------------------------------------------------
P = (('banana', 'ananás', 'abacaxi', 'bola', 'bala', 'caxias'))

B = []
for palavra in P: # para cada palavra em P, gerar os bigramas e inserir em B

    # --- esse é o mesmo código lá de cima
    bigramas = []
    for i in range(len(palavra)-1): # do primeiro ao penultimo caractere
        bg = palavra[i:i+2]         # capturar o bigrama da posição i,i+1
        bigramas.append(bg)         # inserir o bigrama na lista
    # ----
    B.append(bigramas)
        
print('- Parte 1 (bigramas):')
print(f'palavras: {P}')
print(f'bigramas: {B}\n\n')

#------------------------------------------------------------
# PARTE 2: cálculo da similaridade de Jaccard
#          entre 2 listas de bigramas s e t
#------------------------------------------------------------

# vou pegar os bigramas de 'banana' e 'ananás' como teste
s = B[0][:]  # clone do 1o elemento de P -> ['ba', 'an', 'na', 'an', 'na']
t = B[1][:]  # clone do 2o elemento de P -> ['an', 'na', 'an', 'ná', 'ás']

print('- Parte 2 (similaridade de Jaccard):')
print(f'* s={s}     t={t}')

# PASSO 1: ordenar os bigramas
s.sort()
t.sort()
print(f'* após ordenação: s={s}     t={t}')

# PASSO 2: remover repetições
# o jeito mais fácil é usando listas auxiliares...
# criamos uma nova lista vazia e
# não deixamos inserir um mesmo bigrama nela duas vezes
s_novo = []
for bigrama in s:
    if bigrama not in s_novo: s_novo.append(bigrama)

t_novo = []
for bigrama in t:
    if bigrama not in t_novo: t_novo.append(bigrama)

s = s_novo # modifica s
t = t_novo # modifica t

print(f'* após remover repetições: s={s}     t={t}')
        
# PASSO 3: calcula a SJ - Similaridade de Jaccard
# SJ = |intersecao(s, t)| / |uniao(s, t)|
# o jeito mais fácil é criando duas listas: intersecao e uniao

# intersecao (elementos comuns a s e t)
intersecao = []
for bigrama in s:
    if bigrama in t: intersecao.append(bigrama)

# uniao (elementos de s e t, tomando cuidado para não inserir repetidos)
uniao = t[:]
for bigrama in s:
    if bigrama not in t: uniao.append(bigrama)

intersecao.sort() # ordenando só para ficar bonitinho
uniao.sort() # ordenando só para ficar bonitinho

# agora e só calcular a similaridade
sj = len(intersecao) / len(uniao)

print(f'* interseção = {intersecao}')
print(f'* união = {uniao}')
print(f'SJ(s,t) = {sj:.2f}')

# OBS.: O Python possui uma coleção chamada Set
# que facilitaria o processo de cálculo da SJ.
# Porém essa coleção não faz parte da ementa do curso.
