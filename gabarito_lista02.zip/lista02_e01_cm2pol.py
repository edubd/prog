# lista02.01 tabela cm x polegada
cm = 0
print('* * * Tabela de conversão de Centímetros para Polegadas')
while cm <= 100:
    pol = cm * 0.3937
    print(f'{cm:6.2f} centímetros ----> {pol:5.2f} polegadas')
    cm += 5
