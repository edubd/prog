# lista02.08 concatena n múltiplos de 3
n = int(input('Digite um inteiro: '))

i = 0
s = ""  # string que será gerada
x = 3

while i < n:
    i += 1
    s += str(x)
    if i < n: s += "-" # não posso botar o tracinho depois do último múltiplo
    x += 3

print(s)