# lista02.09 testa se é multiplicação de 3 consecutivos
N = 0

while N != -1:
    
    N = int(input('Digite um inteiro positivo ou -1 para sair: '))
    
    if N > 0:
        a = 1
        while (a * (a+1) * (a+2) < N): a += 1  # vai testando, começando por 1 * 2 * 3 (poderia ser otimizado)
    
        # mostra resultado para o usuário
        if a * (a+1) * (a+2) == N:
            print(f'Sim, os números são: {a}, {a+1}, {a+2}')
        else:
            print('Não')
    

    
