# lista02.02 verifica se número é par ou ímpar enquanto o usuário desejar
while True:
    x = int(input('Digite um inteiro: '))
    if x % 2 == 0:
        print('Esse número é par')
    else:
        print('Esse número é ímpar')
    
    resp = input('Deseja digitar mais um número (S/N)?: ')
    if resp == 'N' or resp == 'n': break