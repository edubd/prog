# lista02.03 estatísticas sobre 15 números
import math
MAX = 15

maior = -math.inf   # antes de processar, assume que maior eh -infinito
menor = math.inf    # antes de processar, assume que menor eh +infinito
soma = 0            # acumulará a soma dos números
i = 1

while i <= MAX:
    print('digite o número',i,':');
    n = float(input())
    
    soma += n                # incrementa a soma
    if n > maior: maior = n  # atualiza o maior, se necessário
    if n < menor: menor = n  # atualiza o menor, se necessário
    
    i += 1

print('O menor número é: ', menor)
print('O maior número é: ', maior)
print('A soma é: ', soma)
print('A média é: ', round(soma/MAX,2))