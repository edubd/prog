# lista02.06 menor e maior impar
import math
MAX = 15

menor_par = math.inf    # antes de processar, assume que menor par eh +infinito
menor_impar = math.inf  # antes de processar, assume que menor ímpar eh +infinito
i = 0

while i < MAX:
    i += 1 # só para mostrar que posso incrementar o i de cara ou no final
           # contanto que eu controle corretamente para fazer o número certo de iterações
    
    print('digite o número',i,':');
    numero = float(input())
    
    if numero % 2 == 1: # se for ímpar...
        if numero < menor_impar: menor_impar = numero  # se é menor que ímpar anterior, atualizo
    else:               # se for par...
        if numero < menor_par: menor_par = numero  # se é menor que par anterior, atualizo


if menor_impar == math.inf: menor_impar = 'não há'   
if menor_par == math.inf: menor_par = 'não há'
    
print(f'menor número par: {menor_par}')
print(f'menor número ímpar: {menor_impar}')
