# lista02.10 raiz pelo método das subtrações
x = int(input('Digite um inteiro positivo que calcularei a raiz exata ou aproximada: '))

w = x                  # faz uma cópia de x para w (para não perder o x original)
total_subtracoes = 0   # armazena o total de subtrações
i = 1                  # armazena o ímpar que deve ser correntemente usado
ficar = True

while w > 0:
    w = w - i              # subtrai ímpar atual
    total_subtracoes += 1  # incrementa o total de subtrações realizadas
    i += 2                 # vai para o próximo ímpar
    
# agora é só imprimir o resultado
if x < 0:
    print('Não posso tirar a raiz de um negativo')
else:
    if w == 0: print('A raiz exata de', x, 'é', total_subtracoes)
    else: print('A raiz aproximada de', x, 'é', total_subtracoes)
