# lista02.04 calcula: S = (37 x 38) / 1 + (36 x 37) / 2 + (35 x 36) / 3 + ... + (1 x 2) / 37

n = 38  # valor inicial para o numerador (1o termo)
d = 1   # valor inicial do denominador (1o termo)
S = 0   

while d < 38:
    S += (n-1) * n / d 
    # print(f'({n-1}) * {n} / {d} --> ', (n-1) * n / d) # descomente para "debugar"
    n -= 1
    d += 1

print(f'S = {S:.4f}')