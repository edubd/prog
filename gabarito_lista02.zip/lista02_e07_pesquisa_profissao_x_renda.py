# lista02.07 pesquisa profissao x renda

soma_sal_est = 0  # soma do salário dos estatísticos
tot_est = 0       # total de pessoas c/ profissão estatístico
tot_mat = 0       # total de pessoas c/ profissão matemático
tot_est_5k = 0    # total de estatísticos que ganham mais de 5000
n = 0             # total de entrevistados

profissao = 99 # só para entrar no loop... pode usar while True com break também...

# recebe e processa os dados
while profissao != -1:
    profissao = int(input('Digite a profissão (1=Estatístico, 2=Físico, 3=Matemático): '))
    renda = float(input('Digite a renda: ')) # pega a renda
    
    # apura o resultado apenas se digitou profissão válida e renda válida
    if (1 <= profissao <= 3) and (renda >= 0):
        
        n += 1 # incrementa número de entrevistados
        
        # se for estatístico, atualiza as variáveis adequadas
        if profissao == 1:
            tot_est += 1
            soma_sal_est += renda
            if renda > 5000: tot_est_5k += 1
        
        # se é matemático, atualiza o total de matemáticos
        elif profissao == 2:
            tot_mat += 1

    
# imprime os resultados
print('\n\nRESULTADOS:\n')
if tot_est > 0:
    media_sal_est = soma_sal_est / tot_est
    print(f'Média salario dos estatísticos: {media_sal_est:.2f}')
else:
    print('Não foi digitado nenhum estatístico!!!')
    
print(f'Número de matemáticos: {tot_mat}')
print(f'Número de estatísticos que ganham mais de R$ 5000: {tot_est_5k}')
        