# lista02.05 calcula: S = (N^25 / 1) – (N^24 / 2) + (N^23 / 3) – (N^22 / 4) + ... + (N / 25).

N = float(input('Digite o valor de N: '))

e = 25     # valor inicial para o expoente do numerador (1o termo)
d = 1      # valor inicial do denominador (1o termo)
sinal = 1  # usado para definir se devo somar ou subtrair o termo (1 soma e -1 subtrai)
S = 0   

while d < 26:
    S += (N ** e / d) * sinal
    # print(f'({N} ** {e} / {d}) * {sinal} --> ', (N ** e / d) * sinal, ' ---> ', S) # descomente para "debugar"
    e -= 1
    d += 1
    sinal *= -1 # inverte o sinal...

print(f'S = {S:.4f}')
