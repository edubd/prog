# 1-seção de configuração e definição de variáveis
import pygame
pygame.init()
largura_tela = 640; altura_tela = 480
COR_BRANCA = (255, 255, 255)
COR_AZUL = (0, 0, 255)
COR_VERMELHA = (255, 0, 0)
COR_OLIVE = (128, 128, 0)


tela = pygame.display.set_mode((largura_tela, altura_tela))

def tela_inicial():
    tela.fill(COR_OLIVE)
    escreve_msg(tela, '* * CÓDIGO 3 * *', 320, 240)
    
def escreve_msg(tela, texto, x, y):
    font = pygame.font.Font(None, 32)
    text = font.render(texto, False, COR_BRANCA)
    textpos = text.get_rect()
    textpos.center = (x, y)
    tela.blit(text, textpos)

tela_inicial()

# 2-seção game loop -----------------------------
terminou = False
while not terminou:    
    # 3-seção de tratamento de eventos
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            terminou = True

        if event.type == pygame.MOUSEBUTTONDOWN: #o usuário clicou com o mouse
            # preenche o fundo de branco
            tela.fill(COR_BRANCA)
            
            if event.button == 1:
                # se foi o botão esquerdo
                # desenha um círculo azul de raio 100 no centro
                pygame.draw.circle(tela, COR_AZUL, (320,240), 100)
                
            elif event.button == 3:
                # se foi o botão direito
                # desenha um quadrado vermelho de lado 200 no centro
                pygame.draw.rect(tela, COR_VERMELHA, (220, 140, 200,200))

    # 4-atualização da tela do jogo
    pygame.display.update()
# ---- fim do game loop: encerramos a pygame ---
pygame.display.quit()
pygame.quit()