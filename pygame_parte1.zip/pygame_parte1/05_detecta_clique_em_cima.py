#1-seção de configuração e definição de variáveis
import pygame
pygame.init()
largura_tela = 640; altura_tela = 480
COR_AMARELA = (255, 255, 51)

tela = pygame.display.set_mode((largura_tela, altura_tela))

#define a classe Quadradinho
class Quadradinho:
    
    def __init__(self, x, y, cor):
        self.x = x
        self.y = y
        self.cor = cor
        self.area = pygame.Rect(x, y, 50, 50)
    
    def desenha(self, tela):
        pygame.draw.rect(tela, self.cor, self.area)
        
#cria dois Quadradinhos, q1 e q2
q1 = Quadradinho(300, 100, (0,255,0)) #quadrado verde
q1.desenha(tela)    
q2 = Quadradinho(350, 300, (0,0,255)) #quadrado azul
q2.desenha(tela)

#escreve texto em amarelo, centralizado na posição x,y
def escreve_msg(tela, texto, x, y):
    font = pygame.font.Font(None, 32)
    text = font.render(texto, False, COR_AMARELA)
    textpos = text.get_rect()
    textpos.center = (x, y)
    tela.blit(text, textpos)


#2-seção game loop -----------------------------
terminou = False
while not terminou:    
    #3-seção de tratamento de eventos
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            terminou = True
        #o usuário clicou com o botão esquerdo
        if (event.type == pygame.MOUSEBUTTONDOWN) and (event.button == 1): 
            pos = pygame.mouse.get_pos()  # pega a coordenada (x,y) do clique
            x, y = pos
            tela.fill((0, 0, 0)) # preenche o fundo da tela de preto
            q1.desenha(tela); q2.desenha(tela)  # redesenha os quadrados
            # se clique foi dentro de q1 ou q2, escreve "Dentro!"
            if q1.area.collidepoint(pos) or q2.area.collidepoint(pos):
                escreve_msg(tela, "Dentro!", x, y)
            else: # senão escreve "Fora!"
                escreve_msg(tela, "Fora!", x, y)

    #4-atualização da tela do jogo
    pygame.display.update()
#---- fim do game loop: encerramos a pygame ---
pygame.display.quit()
pygame.quit()