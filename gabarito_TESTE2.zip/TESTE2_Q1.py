# TESTE 2 - Q1: combina dicionários
def soma_dics(d1, d2):
    d = {}
    for chave in d1:
        if chave in d2:
            d[chave] = d1[chave] + d2[chave]
    
    return d


# código para testar função (não era necessário fazer)
print(soma_dics({"a": 100, "c": 800, "e": 300}, {"a": 400, "b": 200, "c": 300, "x": 500}))
print(soma_dics({"a": 10, "x": 20}, {"z": 20}))    