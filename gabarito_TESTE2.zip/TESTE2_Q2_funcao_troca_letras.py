# Teste 2 - Q2: funcao f_troca, inverte letras i e k de uma string s

def f_troca(s, i, k):
    if i >= len(s) or k >= len(s): return None
    
    s_copia = ""
    for x in range(len(s)):
        if x == i: # se estiver na posição i, concatenar caractere da posição k de s
            s_copia += s[k]
        elif x == k: # se estiver na posição k, concatenar caractere da posição i de s
            s_copia += s[i]
        else: # em qualquer outra posição, concatenar caractere da posição x
            s_copia += s[x]
    
    return s_copia

print(f_troca("perfeito", 0, 3))
print(f_troca("rato", 3, 1))
print(f_troca("rato", 4, 3))

# dá para fazer a função de outras maneiras... por exemplo, convertendo a string para lista
# ou usando fatiamento (basta ver quem é maior, i ou k)

