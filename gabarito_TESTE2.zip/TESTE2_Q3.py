# TESTE 2 - Q3: média da turma em teste de múltipla escolha

# código para testar função (não era necessário fazer)
mat = [['A', 'C', 'C', 'E', 'E', 'A', 'D', 'A', 'B', 'B'],
       ['E', 'C', 'C', 'B', 'D', 'A', 'D', 'A', 'D', 'C'],
       ['C', 'A', 'B', 'B', 'E', 'A', 'C', 'D', 'B', 'C'],
       ['E', 'C', 'D', 'B', 'E', 'A', 'B', 'A', 'B', 'C'],
       ['E', 'C', 'B', 'E', 'D', 'A', 'D', 'B', 'C', 'E'],
       ]

g = ['E', 'C', 'C', 'B', 'E', 'A', 'D', 'A', 'B', 'C']

N = len(mat)
tot_questoes = len(mat[0])

# ----------------------------------------------------------
# aqui começa o que foi pedido no enunciado da questão ....

soma_notas = 0
for i in range(N): # percorre cada teste
    nota_aluno_i = 0
    for j in range(tot_questoes): # percorre as respostas
                                  # de cada questão do teste i
                                  
        if mat[i][j] == g[j]: # aluno i acertou questão j
            nota_aluno_i += 1 # entao 1 ponto pra ele
            
    soma_notas += nota_aluno_i 

# agora que todas as notas foram somadas, é só fazer a média turma
print(f'Média da turma: {soma_notas / N:.2f}')
