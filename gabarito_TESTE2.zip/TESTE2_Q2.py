# TESTE 2 - Q2: processa arquivo da pesquisa de acidentes
# (para testar o programa, você precisará criar um CSV)

f = open("c:/bases/acidentes.csv")
f.readline()

tot_linhas = 0 # poderia usar 1000 diretamente, já que enunciado dizia
tot_acidentes = 0
tot_masc_jovem_acidente = 0


for linha in f:
    linha = linha.rstrip()
    dados = linha.split(",")
    
    tot_linhas += 1
    if dados[2] == 'S':
        tot_acidentes += 1
        if dados[0] == 'M' and int(dados[1]) < 30:
            tot_masc_jovem_acidente += 1


pct_acidentes = (tot_acidentes/tot_linhas) * 100
print(f'Perc. pessoas que sofreram acidentes: {pct_acidentes:.2f}%')
print(f'Total sexo masculino, menos de 30 anos, acidente: {tot_masc_jovem_acidente}')

f.close()
