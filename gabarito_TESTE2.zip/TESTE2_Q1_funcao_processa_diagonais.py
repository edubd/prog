# Teste 1 - Q1: funcao que retorna soma dos elementos das diagonais principal
# e secundária de uma matriz quadrada em uma lista

def f_soma(M):
    m = len(M) # ordem da matriz
    
    lst = [] # lista que será retornada
    for i in range(m): # loop com m iterações
        lst.append(M[i][i] + M[i][-(i+1)]) # apendo soma dos elementos das diagonais
                                           # da linha i a cada iteração
    
    return lst # retorno a lista


# código de teste
M = [[11 , 2 ,22 ,19],
     [50 ,49 ,99 ,40],
     [81 , 3 ,31 ,73],
     [52 ,70 ,95 , 4]]

print(f_soma(M))
    