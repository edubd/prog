# Teste 2 - Q3: valor total de uma compra, colocado em um dicionário

#f = open("c:/bases/compras.csv")
f = open("compras.csv") # para testar, botei o csv na mesma pasta
                        # mas na solução do exercício teria que ser na pasta c:/compras

soma = 0
for linha in f:
    linha = linha.strip()
    colunas = linha.split(";")
    
    soma = soma + float(colunas[1])

dic = {"total": soma} # cria dicionário para armazenar o resultado
print(dic)
