# processamento do arquivo de pokemons (exercício 13/6/2024)

arq_ent = open("pokemon.csv", encoding="utf-8")    # abre o arquivo de entrada (BD dos pokémons)
arq_sai = open("SAIDA.TXT", "w", encoding="utf-8")  # abre o arquivo de saida (resultados do processamento)
arq_ent.readline() # pula o cabeçalho

tot1 = 0  # resultado 1: total com Attack > 50, Legendary e Poison no Type1
nomes_maior_vel = []; maior_vel = 0 # resultado 2: mais velozes
lst_ataque = []; media_ataque = 0; tot_pokemons = 0   # resultado 3: ataque acima da média

# loop que processa cada observação (linha) do arquivo
for observacao in arq_ent:
    observacao = observacao.rstrip() # tira o chato \n
    cols = observacao.split(",")     # quebra linha em colunas
    
    tot_pokemons += 1           # atualiza o total de pokemons
    
    # pega logo os valores que interessam para o resultado
    nome = cols[1]
    type_1 = cols[2]
    ataque = int(cols[6])
    velocidade = int(cols[10])
    legendario = cols[12]
    
    # resultado 1: total com Attack >= 150, Legendary "True" e "Rock" ou "Psychic" no Type1
    # CUIDADO: nesse caso 'True' é uma string, pois tudo que é lido de arquivo é string... (não e o True boolean)
    if type_1 in ('Rock', 'Psychic') and legendario == 'True' and ataque >= 150:
        tot1 += 1

    # resultado 2: maior velocidade e nomes dos mais velozes
    if velocidade > maior_vel: # se achei velocidade maior que a atual, atualizo tudo...
        maior_vel = velocidade
        nomes_maior_vel = [nome]
    elif velocidade == maior_vel: # se achei velocidade igual a maior, atualizos os nomes
        nomes_maior_vel.append(nome)

    # resultado 3: guardar todas os valores de Attack, para calcular a média e depois ver quem está acima
    # (ideal é usar list comprehension, mas como é tema opcional, farei sem)
    lst_ataque.append(ataque)
    media_ataque += ataque

# fim do loop... hora de determinar finalizar alguns resultados e gravar arquivo de saida
media_ataque = media_ataque / tot_pokemons
tot_ataque_acima_media = 0
for valor_ataque in lst_ataque:
    if valor_ataque > media_ataque: tot_ataque_acima_media += 1

arq_sai.write('ESTATÍSTICAS DA BASE DE POKÉMONS\n\n')
arq_sai.write(f'(a) Total de legendários, com ataque >= 150 e type_1 “Rock” ou “Psychic”: {tot1}\n')
arq_sai.write(f'(b) maior velocidade: {maior_vel} - nome(s): {str(nomes_maior_vel)}\n')
arq_sai.write(f'(c) média ataque: {media_ataque:.4f} - total com ataque acima da métia: {tot_ataque_acima_media}')

arq_sai.close()
arq_ent.close()
