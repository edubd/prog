# lista05.05 função que coloca 'x' no meio das letras de string
def taca_x(s):
    
    # monta lista com cada letra intercalada com 'x'
    saida = []
    for k in range(len(s)):
       saida.append(s[k])
       saida.append('x')
    
    # tira o último 'x' da lista
    saida.pop()
    
    # retorna a lista transformada lista em string
    return "".join(saida)


# teste da função
print(taca_x('ENCE'))
print(taca_x('123'))
print(taca_x('a'))
print(taca_x('PINDAMONHANGABA'))
