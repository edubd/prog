# lista05.01 tradutor português->inglês->francês
dic_pt2en = {"verde":"green", "amarelo":"yellow", "azul":"blue", "branco": "white"}
dic_en2fr = {"green":"vert", "yellow" :"jaune", "blue":"bleu", "white" : "blanc"}

# sim, é possível -> abaixo, 'amarelo' é traduzido para francês
print(dic_en2fr[dic_pt2en['amarelo']])
