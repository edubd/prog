# lista05.07 MDC com função recursiva implementando Algoritmo de Euclides

"""
Para calcular o mdc(m,n) para 0 <= n < m,
o algoritmo de Euclides usa a seguinte recorrência:

mdc(m,0)   ==  m;
mdc(m,n)   ==  mdc(n, m % n),  para n > 0.
"""

# então é só implementar a função recursiva...
def mdc(m, n):
    if n == 0: return m
    else: return mdc(n, m % n)

 
# código de teste
print(mdc(18, 12))
print(mdc(514229, 317811))

# detalhes completos em:
# https://www.ime.usp.br/~coelho/mac0338-2004/aulas/mdc/index.html

