# lista05.04 função que desenha retangulo com - e |
def desenha_retangulo(lins, cols):
    # ajusta os parâmetros se for necessário
    if lins < 2: lins = 2
    elif lins > 30: lins = 30
    
    if cols < 2: cols = 2
    elif cols > 30: cols = 30
    
    # agora faz o desenho
    for i in range(lins):
        if i == 0 or i == lins-1:
            print("-" * cols)
        else:
            print("|" + " " * (cols-2) + "|")

# testando
print('Retângulo 5 x 20')
desenha_retangulo(5, 20)

print()
print('Retângulo 4 x 3')
desenha_retangulo(4, 3)
