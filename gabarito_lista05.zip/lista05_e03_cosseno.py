# lista05.03 função: cosseno de vetores
# (criei 2 funções auxiliares com list comprehension)

def f_prod_escalar(v1, v2):
    return sum( [i*j for i, j in zip(v1, v2)] )

def f_norma(v):
    return sum( [i**2 for i in v])**0.5

def f_cosseno(v1, v2):
    norma_v1 = f_norma(v1)
    norma_v2 = f_norma(v2)
    if (norma_v1 > 0) and (norma_v2 > 0):
        return f_prod_escalar(v1, v2) / (norma_v1 * norma_v2)
    else: return 0.0


# código de teste
v1 = [0, 2, 1, 2, 0] 
v2 = [1, 2, 0, 1, 1]  
print('\ncosseno v1, v2: ', f_cosseno(v1, v2))
