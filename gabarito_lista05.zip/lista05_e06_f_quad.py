# lista05.06 função f_quad
# OBS: fiz um código mais legível, porém menos otimizado
#      daria para resolver tudo dentro de um for i---for j

def f_quad(mat):
    
    # 1-lista com a soma das linhas
    soma_linhas = []
    for linha in mat:
        soma_linhas.append(sum(linha))
    
    # 2-lista com a soma das colunas
    soma_cols = []
    for j in range(len(mat)):
        soma = 0
        for i in range(len(mat)):
            soma += mat[i][j]        
        soma_cols.append(soma)
    
    # 3-lista com os elementos da diagonal principal
    diag = []
    for i in range(len(mat)):
        diag.append(mat[i][i])
    
    # 4-lista com os elementos da diagonal secundária
    diag_sec = []
    for i in range(len(mat)):
        diag_sec.append(mat[i][-(i+1)])    
        
    # retorno da função
    return soma_linhas, soma_cols, diag, diag_sec


# código para teste da função
m = [[1, 0, 8],
     [4, 2, 6],
     [3,10, 2]]

resultado = f_quad(m)

print(resultado)