# lista05.02 tabula função f(x,y)
def f(x, y):
    num = x**2 + 3*x + y**2
    den = x*y - 5*y - 3*x + 15
    if den != 0:
        return num/den
    else:
        return None


# tabulando para os valores do enunciado
for x in range(1, 11):
    for y in range(6):
        valor = f(x**2,y)
        if valor is not None: # se valor não é None
            print(f'f({x**2},{y}) = {valor:>10.5f}')
        else: # quando valor é None, não dá para usar máscara de formatação
            print(f'f({x**2},{y}) =       -')
