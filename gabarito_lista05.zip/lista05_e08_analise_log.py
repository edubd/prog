# lista05.08 Análise do arquivo de log

# PARTE 1: processa o arquivo de entrada 
f_in = open("log.txt")

soma_espaco = 0
lista_gastoes = []

for linha in f_in:
    linha = linha.split(";")
    
    # criei uma variável para login e outra para o espaço
    # como o "\n" vai só para a última posição da lista posso dar o rstrip só nele...
    login = linha[0]
    espaco = int(linha[1].rstrip())
    
    soma_espaco += espaco
    if espaco > 1000000:
        lista_gastoes.append(login)

f_in.close()

# PARTE 2: joga os resultados computados em um arquivo de saida
# (não gravei como UTF-8)
f_out = open("resultados.txt", "w")
f_out.write('Processamento do arquivo de LOG\n' + '='*31 + '\n\n')
f_out.write(f'Espaço total ocupado: {soma_espaco:.2f}\n')
f_out.write(f'Logins ocupando mais de 1.000.000 kbytes: {str(lista_gastoes)}\n')

f_out.close()


