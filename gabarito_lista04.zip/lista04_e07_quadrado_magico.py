# lista04.07 verifica se matriz quadrada é quadrado mágico
"""
------------------------------------------------------------
* * UMA POSSÍVEL SOLUÇÃO * * 

Armazenar a soma de cada coluna numa lista de tamanho m, chamado "soma_cols"
Armazenar a soma de cada linha numa lista de tamanho m, chamado "soma_linhas"
Armazenar a soma da diagonal principal na variável "soma_prin"
Armazenar a soma da diagonal secundária na variável "soma_sec"

Depois analisar se todos os valores armazenados são iguais...
------------------------------------------------------------
"""

# matriz exemplo (3x3)
mat = [[8, 0, 7], 
       [4, 5, 6],
       [3, 10, 2]]

# mat[0][1] = 1 # descomente para a matriz deixar de ser mágica

m = len(mat)  # retorna o número de linhas da matriz

#------------------------------------------------------------
# * *  TRECHO DE CÓDIGO PEDIDO NO EXERCÍCIO * *
#------------------------------------------------------------

# PASSO 1 --- essa rotina fará todas as somas necessárias e armazenará os valores
soma_prin = soma_sec = 0
soma_linhas = []
soma_cols = []


for i in range(m):
    soma_col_i = 0
    soma_lin_i = 0
    for j in range(m):
        
        # atualiza a soma da diagonal principal
        if i == j: soma_prin += mat[i][j]

        # atualiza a soma da diagonal secundária
        if i + j == m - 1: soma_sec += mat[i][j]

        # atualiza soma dos elementos da linha i
        soma_lin_i += mat[i][j]

        # atualiza soma dos elementos da coluna i
        soma_col_i += mat[j][i]  # observem a posição de j e i nesse caso

    soma_linhas.append(soma_lin_i)
    soma_cols.append(soma_col_i)

# PASSO 2 --- VERIFICAR SE É MÁGICA

# agora analiso os somatórios... se algum valor armazenado for diferente
# a matriz não é um quadrado mágico 

# vamos comparar a soma de cada linha
# e a soma de cada coluna com a soma das diagonais... se algunzinho for
# diferente, então não é um quadrado mágico - muito triste :(((((

eh_magica = True # parto da hipotése que é mágica
for i in range(m):
       if (
           (soma_cols[i] != soma_sec) or
           (soma_cols[i] != soma_prin) or
           (soma_linhas[i] != soma_sec) or
           (soma_linhas[i] != soma_prin)
           ):
              eh_magica = False
              break

if eh_magica:
    print('Essa matriz É MÁGICA!!!')
else:
    print('Essa matriz NÃO É MÁGICA!!!')

"""
------------------------------------------------------------
 * *  COMENTÁRIOS * * 

  para a matriz que coloquei no exemplo as variáveis estariam
  com a seguinte configuração após o passo 1

  soma_cols = |15|    soma_linhas = |15|    soma_prin = 15
              |15|                  |15|    soma_sec = 15
              |15|                  |15|

  por isso a matriz fica sendo mágica 

  mas se você mudar o programa e fizer mat[0][1] = 1 a configuração
  das variáveis será:

  soma_cols = |15|    soma_linhas = |16|    soma_prin = 15
              |16|                  |15|    soma_sec = 15
              |15|                  |15|
 

  aí a matriz deixa de ser mágica 
    
------------------------------------------------------------
"""