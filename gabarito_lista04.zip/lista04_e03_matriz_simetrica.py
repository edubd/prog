# lista04.03 verifica se matriz e simétrica 
"""
Exemplo de matriz simétrica MxM, onde M=3:
|2    5  11|
|5    4  17|
|11  17   6|
"""

# 1. Cria a matriz quadrada
MAXIMO = 50
m = 0
while m < 2 or m > MAXIMO:
    print('Entre com o valor de m (entre 2 e', MAXIMO, '):')
    m = int(input())

A = []
for i in range(m):
    A.append([0] * m)

# 2. recebe os dados da matriz via teclado
print('Entre com os elementos da matriz'); print()
for i in range(m):
    for j in range(m):
        print('A[', i, ',', j, '] = ', end="")
        A[i][j] = float(input())

# 3. agora vamos verificar se A é simétrica:
eh_simetrica = True  # parte da hipótese de que é simétrica
for i in range(m):
    for j in range(m):
        if A[i][j] != A[j][i]: # verifica se hipótese foi quebrada
            eh_simetrica = False
            break

# 4. imprime se é ou não...
if eh_simetrica:
    print('A matriz digitada é simétrica')
else:
    print('A matriz digitada não é simétrica')
    
