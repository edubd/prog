# lista04.08 string compactada

s  = "SOCORRAM-ME AGORA"
s  = "Amor a Roma!?"

# cria uma lista contendo só as letras da string
# o método isalpha() é usado para testar se caractere é letra ou não
lst_letras = []
for i in range(len(s)):
    if s[i].isalpha():
        lst_letras.append(s[i])
        
# usa o método join() para transformar a lista em string
compactada = "".join(lst_letras)

print(compactada)