# lista04.02 multiplicação de matrizes

# matrizes A e B de exemplo 
# (mas seu programa tem que funcionar p/ qq A e B)
A = [[3, 2],
     [5, -1]]

B = [[6, 4, -2],
     [0, 7,  1]]

# ---- aqui começa o que foi pedido no enunciado ----
print('Programa Multiplicação de Matrizes')
print('==================================')

# PASSO 1: obtém a quantidade de linhas e colunas das matrizes A e B
#          e verifica se operação é possível
LIN_A = len(A); COL_A = len(A[0])
LIN_B = len(B); COL_B = len(B[0])

if (COL_A != LIN_B):
    print('Não poderei multiplicar A por B, pois o número de colunas de A ')
    print('é diferente do numero de linhas de B')


# PASSO 2: se operação é possível, calcula P = A x B
else:
    # cria m, n e p apenas para compatibilizar com o enunciado
    m = LIN_A
    n = COL_A # que é igual à LIN_B
    p = COL_B
    
    # cria a matriz P (mxp) toda zerada
    P = []
    for i in range(m): P.append([0.0] * p) # cria P toda zerada
    
    for i in range(m):     # percorre as linhas de A
        for j in range(p): # percorre as colunas de B
            aux = 0
            for z in range(n): # percorre a dimensão 'n' comum às duas matrizes
                aux += A[i][z] * B[z][j]
            
            P[i][j] = aux
                
    # -----------------------------------------------
    # imprime A, B e P
    # -----------------------------------------------
    print()
    print('Matriz A')
    print('--------')
    for i in range(m):
        for j in range(n):
            print("{:>10.2f}".format(A[i][j]), end=" ")
        print()    
            
    print()
    print('Matriz B')
    print('--------')
    for i in range(n):
        for j in range(p):
            print("{:>10.2f}".format(B[i][j]), end=" ")
        print()    

    print()
    print('Matriz P = A x B')
    print('----------------')
    for i in range(m):
        for j in range(p):
            print("{:>10.2f}".format(P[i][j]), end=" ")
        print()    
