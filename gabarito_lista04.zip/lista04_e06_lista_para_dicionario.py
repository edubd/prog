# lista04.06 transforma 2 listas "disc" e "salas", de mesmo tamanho, em um dicionário
disc = ["PROBAB", "BD", "CALC I", "CALC II"]
salas = [105, 203, 107, 305]
n = len(disc)

d = {}
for i in range(n):
    d[disc[i]] = salas[i]

print(d)

