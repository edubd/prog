# lista04.01 verifica se há elemento repetido em matriz

# matriz exemplo 
# (mas seu programa tem que funcionar p/ qq matriz)
mat = [[30, 18, 50, 90],
       [35, 10, 40, 12],
       [13, 20, 30, 100]]

# ---- aqui começa o que foi pedido no enunciado ----
m = len(mat); n = len(mat[0]) # núm. de linhas e colunas

repetido = False # parte da hipótese de que não há
for i in range(m):
    for j in range(n):
        atual = mat[i][j] # pega o elemento atual
        
        # define a linha e coluna a partir de onde
        # vai será procurar.
        if j == n-1:
            lin_inicio = i+1
            col_inicio = 0
        else:
            lin_inicio = i
            col_inicio = j + 1
        
        # verifica o resto da matriz
        # (todas as células posteriores a i,j
        for u in range(lin_inicio, m):
            for v in range(col_inicio, n):
                if mat[i][j] == mat[u][v]:
                    repetido = True
                    
                
if repetido: print('Sim, há pelo menos um elemento repetido')
else: print('Não há elemento repetido')

"""
# ----------------------------------------------------
# outro exemplo de solução, usando in
# ----------------------------------------------------

repetido = False # parte da hipótese de que não há
for i in range(m):
    for j in range(n):
        atual = mat[i][j] # pega o elemento atual
        
        # 1 - se o atual não está na última coluna
        # verifica se ele aparece no restante da linha i
        if (j < n-1):
            if atual in mat[i][j+1:]: repetido = True
        
        # 2 - se o atual não está na última coluna
        # verifica se ele aparece nas outras linhas
        if (i < m-1):
            for k in range(i+1,m):
                if atual in mat[k]: repetido = True

print('SOLUÇÃO (MÉTODO 2)')
if repetido: print('Sim, há pelo menos um elemento repetido')
else: print('Não há elemento repetido')
"""