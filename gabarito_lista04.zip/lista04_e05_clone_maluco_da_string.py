# lista04.05 gera clone esquisito
s = 'calça clochard'   # teste também com 'ENCE', 'Araraquara', 'água', 'kkkkk', ...

# 1. converte para minúsculo
s_min = s.lower()

# 2. gera clone esquisito, levando acentos em consideração
primeira_letra = s_min[0]
letra_alvo = primeira_letra

# 2(a) tratamento dos acentos (considerando a língua Portuguesa)
# (sem usar "maketrans", que não cai na prova, dá trabalho...)
if primeira_letra in ('aáâãà'): # trata possíveis acentos de 'a'
    letra_alvo = 'a'
    s_min = s_min.replace('á','a')
    s_min = s_min.replace('â','a')
    s_min = s_min.replace('ã','a')
    s_min = s_min.replace('à','a')
elif primeira_letra in ('eéê'): # trata possíveis acentos de 'e'
    letra_alvo = 'e'
    s_min = s_min.replace('é','e')
    s_min = s_min.replace('ê','e')
elif primeira_letra in ('ií'): # trata possíveis acentos de 'i'
    letra_alvo = 'i'
    s_min = s_min.replace('í','i')
elif primeira_letra in ('oóôõ'): # trata possíveis acentos de 'o'
    letra_alvo = 'o'
    s_min = s_min.replace('ó','o')
    s_min = s_min.replace('ô','o')
    s_min = s_min.replace('õ','o')
elif primeira_letra in ('uú'): # trata possíveis acentos de 'i'
    letra_alvo = 'u'
    s_min = s_min.replace('ú','u')
elif primeira_letra in ('cç'): # trata cedilha
    letra_alvo = 'c'
    s_min = s_min.replace('ç','c')

# 2(b) agora é só gerar o clone
s_clone = primeira_letra + s_min[1:].replace(letra_alvo, '$')

# verificando se tudo deu certo
print(s_clone)