# lista04.04 palavra é palíndromo?

palavra = 'Hannah'
# teste com outros exemplos de palíndromos como 'osso', 'arara'
# e de não palíndromos como 'ENCE', 'abc'

n = len(palavra)
eh_palindromo = True # assume que é...

for i in range(n//2):
    if palavra[i].upper() != palavra[n-i-1].upper():
        eh_palindromo = False
        break

if eh_palindromo:
    print(f'{palavra} é palíndromo')
else:
    print(f'{palavra} não é palíndromo')
    

