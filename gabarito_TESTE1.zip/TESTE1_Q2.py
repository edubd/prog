# TESTE 1 - Q2: verifica se lista w com n>=2 elementos tem a forma [x, 3x, 6x, 9x, ...]

w = [4, 12, 24, 36, 48] # exemplo SIM
#w = [10, 30, 100]      # exemplo NÃO - descomente para testar

# ---------------------------------------------------
# seu programa no teste começaria dessa linha
# ---------------------------------------------------
n = len(w) # pega o número de elementos de w

# a estratégia será a da "quebra de hipótese":
# vou assumir que é SIM, e dentro do for vejo se hipótese é quebrada

primeiro = w[0] # pega o primeiro elemento
k = 3           # dentro do loop k vai valer 3, 6, 9, ...
resposta = True # assume que e SIM

for i in range(1, n): # compara do segundo elemento em diante se ele é igual a k * primeiro
    
    if w[i] != k * primeiro: # se furou, "quebro a hipótese" e posso quebrar o laço
        resposta = False
        break
    
    k += 3 # se não furou, atualizo k e vou testar o próximo elemento (caso exista)
    
if resposta: print('Sim')
else: print('Não')


        