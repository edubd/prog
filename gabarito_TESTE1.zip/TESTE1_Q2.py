# Q2: pesquisa ocupação x salário x idade

# definição das variáveis para as estatísticas pedidas
qtd_E_30 = 0       # quantidade de ocupação=Empregado e idade > 30
qtd_idosos_10k = 0 # idosos que trabalham e ganham > 10k
soma_renda = 0     # soma da renda

# coleta de dados
n = 0 # total de pessoas
while True:
    print(f'Digite os dados do entrevistado {n+1}:')
    ocupacao = input('Ocupação (A=Aposentado, E=Empregado, C=Conta-Própria): ')
    renda = float(input('Renda: '))
    idade = int(input('Idade: '))
    print()
    
    if idade == -1:
        break # digitado o flag de saída, fim da pesquisa
    else:
        n += 1              # atualiza o total de pessoas
        soma_renda += renda # atualiza a renda
        if ocupacao == "E" and idade > 30: # atualiza a estatística 1
            qtd_E_30 += 1
        if ocupacao != "A" and idade >= 65 and renda >= 10000: # atualiza a estatística 2
            qtd_idosos_10k += 1

# agora é só imprimir as estatísticas
if n == 0:
    print('Nenhum dado foi digitado')
else:
    renda_media = soma_renda / n
    print(f'Quant. Empregados com mais de 30 anos: {qtd_E_30}')
    print(f'Quant. idosos, não aposentados, c/ renda 10k ou superior: {qtd_idosos_10k}')
    print(f'Renda média: {renda_media: .2f}')
    
