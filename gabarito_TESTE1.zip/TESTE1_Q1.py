# TESTE 1 - Q1: CANDIDATO (SENADOR, DEPUTADO OU NADA)
print('Avalie se você pode se candidatar...')
idade = int(input('Qual a sua idade? '))
tempo = int(input('Há quantos anos mora no pais? '))

# decidi tratar a exceção primeiro, depois se pode ser senador,
# depois se apenas deputado e por ultimo se não pode nada
# (mas daria para fazer de outras formas)
if idade < 0 or tempo < 0 or tempo > idade: 
    print('Dados inválidos')
elif idade >= 30 and tempo >= 9:
    print('Você pode concorrer a deputado e senador')
elif idade >= 25 and tempo >= 7:
    print('Você pode concorrer a deputado')
else:
    print('Você não pode concorrer a nenhum cargo')



   