# Q1: gera lista c, onde c[i] = |a[i] - b[i]|
a = [2, 1, 1, 6]; b = [0, 3, 1, 3]

# ---- o trecho de código pedido começa aqui --- #
n = len(a)  # pelo enunciado, sabemos que a e b têm o mesmo tamanho

c = []
for i in range(n):
    dif = abs(a[i] - b[i])
    c.append(dif)

# ---- o trecho de código pedido termina aqui --- #
print(c) # só para conferir