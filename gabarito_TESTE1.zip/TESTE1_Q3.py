# TESTE 1 - Q3: Pesquisa Prática Esportiva dos Idosos

N = 150
F1 = F2 = F3 = M1 = M2 = M3 = 0 # inicializa os 6 contadores com 0

# agora começa a pegar os dados
print('PESQUISA IDOSOS x ESPORTES')
print('==========================')
for i in range(N):
    
    # pega os dados da pessoa atual (vamos assumir que usuário digitou corretamente)
    print('Pessoa', i+1)
    g = input('Gênero (F ou M): ')
    e = input('Freq. com que pratica esportes (1=Nunca, 2=Às vezes, 3=Diariamente): ')
    
    # atualiza o contador adequado, de acordo com os dados da pessoa atual
    if g == 'F' or g == 'f': # FEMININO
        if e == '1': F1 += 1
        elif e == '2': F2 += 1
        elif e == '3': F3 += 1
    elif g == 'M' or g == 'm': # MASCULINO  
        if e == '1': M1 += 1
        elif e == '2': M2 += 1
        elif e == '3': M3 += 1

# acabou a coleta e apuração dos dados, posso imprimir os resultados
print()
print(F1, '-' * 10, M1)
print(F2, '-' * 10, M2)
print(F3, '-' * 10, M3)
        
        
    