# lista01.01 converter algoritmo para Python

p = int(input('Digite o valor de p: '))
q = int(input('Digite o valor de q: '))
r = int(input('Digite o valor de r: '))

a = 100 * (q // p) + r   # o uso de parênteses é necessário
                         # para q // p ser feito em vez de 100 * q

b = p * (r % 5) - q / 2 # o uso de parênteses é necessário
                         # para r % 5 ser feito em vez de p * r

print("a =",a, "---- b =", b)