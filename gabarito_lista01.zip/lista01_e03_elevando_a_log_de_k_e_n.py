# lista01.03 elevando a log(k) e a log(n)

import math # tenho que usar o módulo math, pois a função log está nele

print('Digite dois valores reais, k>0 e n>0:')
k = float(input('k: '))
n = float(input('n: '))

# math.log10 calcula logaritmo na base 10
w = n ** math.log10(k)   
u = k ** math.log10(n)

print(w, u)  # w e u serão iguais...
