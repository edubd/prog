# lista01.02 cálculo de y com fração

x = float(input('Digite x (real): '))

y = 1 / (x + 1 / (x + 1 / (x + 1 / x)) )
print("y =", y)

"""
se o usuário digitar: 1
y = 0.6000000000000001 

se o usuário digitar: 10
y = 0.09901951266867294 

se o usuário digitar:  -5
y = -0.19258202567760344

se o usuário digitar:  0
... vai dar erro de divisão por 0
"""