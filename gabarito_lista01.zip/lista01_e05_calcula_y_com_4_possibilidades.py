# lista01.05 cálculo de y com 4 possibilidades usando elif

x = float(input('Digite x (real): '))

# calculei y dentro do print diretamente, já que as contas eram simples...
if x <= 1:
    print('y = 1')
elif x > 1 and x <= 2:
    print('y = 2')
elif x > 2 and x <= 3:
    print('y =', x ** 2)
else:
    print('y =', x ** 3)
    
