# lista01.10 - aposentadoria

# PARTE 1: recebe os dados
print('Veja quando você vai se aposentar')
print('=================================')
sexo = input('digite o gênero (M=Masculino/F=Feminino): ')
idade = int(input('digite a sua idade atual: '))
tempo = int(input('digite o seu tempo de contribuição: '))

# PARTE 2: verifica a situação, tratando em separado os casos de homem e mulher
if sexo == 'M' or sexo == 'm': # HOMEM
    if idade >= 62 or tempo >= 35:
        print('Você já pode se aposentar, parabéns!')
    else:
        falta_idade = 62 - idade
        falta_tempo = 35 - tempo
        #operador ternário
        tempo_que_falta = falta_idade if falta_idade < falta_tempo else falta_tempo # usei operador ternário (ver final da aula 5)
        print('falta(m)', tempo_que_falta, 'ano(s) para você se aposentar')
else: #MULHER        
    if idade >= 60 or tempo >= 30:
        print('Você já pode se aposentar, parabéns!')
    else:
        falta_idade = 60 - idade
        falta_tempo = 30 - tempo
        #operador ternário
        tempo_que_falta = falta_idade if falta_idade < falta_tempo else falta_tempo # usei operador ternário (ver final da aula 5)
        print('falta(m)', tempo_que_falta, 'ano(s) para você se aposentar')
