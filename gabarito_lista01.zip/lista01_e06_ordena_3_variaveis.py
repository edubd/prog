# lista01.06 "ordena" variáveis a, b e c

"""
uma boa abordagem é comparar os pares de variáveis progressivamente,
ordenando-as se necessário. Veja:

a = 10, b = 1, c = 5

(1) compara "a" com "b": a < b ?  -> SIM, então troca o conteudo das duas
a = 1, b = 10, c = 5

(2) compara "a" com "c": a < c ?  -> NÃO, então não faz nada 
a = 1, b = 10, c = 5

(3) por fim, compara "b" com "c": b < c ?  -> SIM, então troca o conteudo delas
a = 1, b = 5, c = 10


Agora que o algoritmo está pronto, é só implementar no Python
Vai dar certo para quaisquer valores de a, b e c
"""

# troque os valores de a, b, c para fazer diferentes testes
a = 10; b = 1; c = 5

if a > b:
    temp = a
    a = b
    b = temp

if a > c:
    temp = a
    a = c
    c = temp

if b > c:
    temp = b
    b = c
    c = temp

print(a, b, c)

# obs: nesse programa não fiz a entrada com input()
# pois o foco era o processo de ordenação
# o próprio enunciado não pedia entrada (deem uma olhada)
        