# lista01.08 - calcula as calorias

# PARTE 1: recebe os dados
print('Cálculo das calorias de uma refeição')
print('====================================')

print('Escolha o prato principal (V=Vegetariano/F=Frango/M=Massa/C=Churrasco)')
principal = input()

print('Escolha a bebida (A=Água/S=Suco de Laranja/G=Guaraná)')
bebida = input()

print('Escolha a sobremesa (A=Abacaxi/M=Mousse)')
sobremesa = input()

# PARTE 2: agora é só calcular as calorias

# 2.1 - inicia com as calorias do prato principal
if principal == 'V' or principal == 'v':
    calorias = 180
elif principal == 'F' or principal == 'f':
    calorias = 230
elif principal == 'M' or principal == 'm':
    calorias = 260
elif principal == 'C' or principal == 'c':
    calorias = 300

# 2.2 - acrescenta as calorias da bebida
if bebida == 'S' or bebida == 's':
    calorias += 70
elif bebida == 'G' or bebida == 'g':
    calorias += 180
# obviamente, não é preciso fazer nada se for água...

# 2.3 - por fim,acrescenta as calorias da sobremesa
if sobremesa == 'A' or sobremesa == 'a':
    calorias += 75
elif sobremesa == 'M' or sobremesa == 'm':
    calorias += 200
    
#agora é só imprimir as calorias totais
print('O total de calorias de sua refeição é: ', calorias)
