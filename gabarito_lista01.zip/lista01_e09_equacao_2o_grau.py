# lista01.09 - resolve equacao 2o grau
print('Resolvendo equações do 2o grau')
print('==============================')
print()
print('Digite os valores de a, b, e c, , onde a, b e c são números reais e a≠0')
a = float(input('a = '))

if a == 0:
    print('entrada inválida !!!')
else:
    b = float(input('b = '))
    c = float(input('c = '))
    
    # calcula delta
    delta = b ** 2 - 4 * a * c
    
    # em função do valor de delta, calcula e informa as raízes
    # para os diferentes casos
    if delta < 0:
        print('Nenhuma raiz real')
    elif delta == 0:
        raiz = (-b) / (2 * a)
        print('raiz 1 = raiz 2 =', round(raiz,4))
    else:
        raiz1 = (-b + delta ** 0.5) / (2 * a)
        raiz2 = (-b - delta ** 0.5) / (2 * a)
        print('raiz 1 =', round(raiz1,4))
        print('raiz 2 =', round(raiz2,4))
        


