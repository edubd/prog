# lista01.07 - área do quadrado ou retângulo
figura = input('Digite o tipo de figura (Q=Quadrado ou R=Retângulo): ')

if figura == 'Q' or figura == 'q': # quadrado
    lado = float(input('Digite o valor do lado: '))
    area = lado * lado
    print('área = ', area)
elif figura == 'R' or figura == 'r': # retângulo
    largura = float(input('Digite o valor da largura: '))
    altura = float(input('Digite o valor da altura: '))
    area = largura * altura
    print('área = ', area)
else:
    print('Entrada inválida')