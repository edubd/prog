# lista01.04 Posições relativas entre um ponto e uma circunferência
# https://www.preparaenem.com/matematica/posicao-um-ponto-relacao-uma-circunferencia.htm

import math

print('Posições relativas entre um ponto e uma circunferência')
print('======================================================')
print()
r = float(input('Digite o raio de uma circunferência com centro em (0,0): '))
print()
print('Digite as coordenadas x,y de um ponto P(x,y):')
x = float(input('x: '))
y = float(input('y: '))

# primeiro calculamos a distância do ponto ao centro da circunferência
# dist = raiz(x - xo)^2 + (y - yo)^2)
# como o centro é (0, 0), ou seja xo=0 e yo=0, pode-se calcular assim:
distancia = math.sqrt(x ** 2 + y ** 2)

# agora é só verificar o valor dessa distância
# em relação ao raio da circunferência
if distancia == r: 
    print('O ponto pertence à circunferência')
elif distancia > r:
    print('O ponto é externo à circunferência')
else:
    print('O ponto é interno à circunferência')
    