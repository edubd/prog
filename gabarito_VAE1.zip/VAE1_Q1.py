# VAE1 - questão 1 (sistema de recomendação)
print('Saiba o tipo de carro que você precisa alugar!')
print('==============================================\n')
r = input('Possui filhos (S/N)? ')
if r == 'S':
    r = input('Mais de 3 (S/N)? ')
    if r == 'S':
        print('Minivan')
    else:
        print('SUV')
else:
    r = input('Gosta de F1? ')
    if r == 'S':
        print('Esportivo')
    else:
        r = input('Vai pro campo? ')
        if r == 'S':
            print('Offroad')
        else:
            print('Sedã')


