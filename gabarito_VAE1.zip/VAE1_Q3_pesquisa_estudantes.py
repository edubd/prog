# VAE 1 - Q3: pesquisa com estudantes

N = 200              # total de questionários
soma_posicao = 0     # soma posição dos estudantes
soma_posicao_E = 0   # soma posição dos estudantes de estatística
qtd_E5 = 0           # quant. estudantes de estatística com posição >= 5

# coleta e apuração
for i in range(N):
    # coleta o questionário corrente
    print('\n-> Questionário', i+1)
    curso = input('Curso (E=Estatística | C=Computação): ')
    posicao = int(input('Posição (1 a 7): '))    
    
    # atualiza a apuração
    soma_posicao += posicao
    if curso == 'E':
        soma_posicao_E += posicao
        if posicao >= 5:
            qtd_E5 += 1

# resultados
media_posicao = soma_posicao / N
media_posicao_E = soma_posicao_E / (N//2)
prob_cond_E5 = qtd_E5 / (N//2)

print('\n-> RESULTADOS:\n===========')
print(f'posição média: {media_posicao: .2f}')
print(f'posição média - Estud. Estatística: {media_posicao_E: .2f}')
print(f'P(pos >= 5|curso="E"): {prob_cond_E5: .2f}')

