# VAE 1 - Q1: norma do vetor U

U = [1, -2, 3]

# --- aqui começa o trecho solicitado --- 

n = len(U)

norma = 0
for i in range(n): norma += U[i]**2 # soma do quadrado dos elementos
norma = norma ** 0.5 # tira raiz da soma

# --- aqui termina o trecho solicitado --- 

print(norma)