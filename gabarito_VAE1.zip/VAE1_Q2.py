# VAE1 - questão 2 (lista do pi)
N = 3000
lst_pi = []
sinal = 1
den = 1

# gera a lista
for i in range(N):
    termo = (4 / den) * sinal
    lst_pi.append(termo)
    den += 2
    sinal *= -1

# imprime PI
print(sum(lst_pi))

