# VAE1 - questão 3 (pesquisa empresas)
n = 1200
soma_sal = qtd_50 = soma_sal_50 = 0

for i in range(n):
    print(f'\nQuestionário {i+1}:')
    razao = input('Razão Social: ')
    po = int(input('Qtd. de funcionários: '))
    sal = float(input('Gasto com salários: '))
    
    soma_sal += sal
    if po > 50:
        soma_sal_50 += sal
        qtd_50 += 1

print(f'Média de gasto com salários: {soma_sal/n:.2f}')
print(f'Quant. emps. c/ mais de 50 func.: {qtd_50}')
print(f'Média gasto salários - emps c/ mais de 50 func.: {soma_sal_50/qtd_50:.2f}')
