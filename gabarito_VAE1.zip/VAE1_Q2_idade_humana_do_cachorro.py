# VAE 1 - Q2: qual a idade "humana" de um cachorro?
# regra:
# 1o e 2o anos valem 10
# 3o e 4a anos valem 8
# 5o ano em diante vale 7

idade_c = int(input('Digite a idade do cachorro: '))

if idade_c < 3:
    idade_h = 10 * idade_c
elif idade_c < 5:
    idade_h = 20 + (idade_c - 2) * 8
else:
    idade_h = 36 + (idade_c - 4) * 7    

print('Idade humana equivalente =', idade_h)