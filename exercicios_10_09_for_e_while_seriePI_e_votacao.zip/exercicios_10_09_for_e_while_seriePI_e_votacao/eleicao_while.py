# eleição para síndico (Rakesh x Zaki) com número indefinido de eleitores (votação e apuração)
# Obs1.: eleição é anulada se maioria dos votos é nula
# Obs2.: Rakesh ganha se empatar com Zaki

# recebe votos e atualiza contagem
rakesh=0; zaki=0; nulos=0
while True:
    print('-' * 40)
    print('VOTE\n====')
    print('1-Rakesh\n2-Zaki')
    voto = input()
    if voto == '1': rakesh += 1
    elif voto == '2': zaki += 1
    elif voto == '999': break
    else: nulos += 1

# verifica totais de votos e divulga resultado
if nulos > rakesh and nulos > zaki:
    print('Eleição anulada')
else:
    if rakesh >= zaki: print('Rakesh venceu!')
    else: print('Zaki venceu')
print(f'---> Nulos: {nulos}, Rakesh: {rakesh}, Zaki: {zaki}')