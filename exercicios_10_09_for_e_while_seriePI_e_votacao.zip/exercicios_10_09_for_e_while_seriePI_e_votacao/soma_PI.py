# calcular PI = 4 - 4/3 + 4/5 - 4/7 + ...
# usando DEZ MIL termos
N = 10000
PI = 0  # receberá o resultado do cálculo da série
den = 1 # receberá o denominador a cada iteração

for i in range(N):
    termo = 4/den
    if i % 2 == 0:
        PI += termo
    else:
        PI -= termo
    den += 2

print(PI)
    
