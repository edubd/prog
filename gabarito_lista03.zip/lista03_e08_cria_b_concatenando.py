# lista03.08 cria b concatenando elementos de a com faixa 1 a k

# lista e k (exemplos)
# (mas seu programa tem que funcionar para toda lista e todo k positivo)

a = ['oi', 'tchau']
k = 3

# ---- aqui começa o que foi pedido no enunciado ----
b = []
for i in range(1, k+1):
    for elemento in a:
        valor = elemento + str(i)
        b.append(valor)

print('a =',a,'e k =',k,'->', b)


