# lista03.04 conta número de digitos de um inteiro
x = int(input('Digite um inteiro: '))

aux = x                # faz uma cópia de x
if aux < 0: aux *= -1  # ajusta para funcionar também para negativos

tot_digitos = 1
while aux // 10 > 0:   # divide sucessivamente por 10 para pegar o total de digitos
    tot_digitos += 1
    aux //= 10

print(f'{x} tem {tot_digitos} digito(s)')