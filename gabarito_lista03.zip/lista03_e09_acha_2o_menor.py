# lista03.09 acha 2o menor valor sem ordenar

# lista exemplo
# (mas seu programa tem que funcionar p/ qq lista de qq tamanho)
u = [30, 50, 50, 35, 30, 40, 30, 100]

# ---- aqui começa o que foi pedido no enunciado ----
menor = min(u) 
segundo_menor = max(u)

for x in u:
    if x < segundo_menor and x != menor:
        segundo_menor = x

print('O segundo menor número é:', segundo_menor)


