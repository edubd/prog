# lista03.05 produtório dos elementos de uma lista

# lista exemplo
# (mas seu programa tem que funcionar p/ qq lista de qq tamanho)
u = [10, 0.20, 4]

# ---- aqui começa o que foi pedido no enunciado ----
p = 1
for numero in u:
    p *= numero

print(u, '-->', p)
