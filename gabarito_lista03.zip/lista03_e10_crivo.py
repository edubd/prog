# lista03.10 Crivo de Eratóstenes

# (i) cria lista com 1001 posições, as 2 primeiras com 0 e as demais com 1
l = [0] * 2 + [1] * 999

# (ii) começando da posição i=2, sempre que posição tiver valor 1
#      faço laço pelo restante da lista e defino como 0 
#      todos os elementos cujo índice for múltiplo de i
for i in range(2, 1001):
    if l[i] == 1:
        for j in range(i+1, 1001):
            if j % i == 0:
                l[j] = 0

# (iii) imprime os primos (índices com valor 1)
print('primos entre 2 e 1000:\n')
for i in range(2, 1001):
    if l[i] == 1: print(i)

