# lista03.01 calcular S = (1/2) - (3/4) + (5/8) - (7/16) + ... para os 50 primeiros termos

maximo = 50
numerador = 1
denominador = 2
sinal = 1
S = 0

for i in range(maximo):
    S += (numerador / denominador) * sinal # atualiza a soma
    #print(f'({i+1:>2}) {numerador}/{denominador} * {sinal}') # debug
    
    # ajusta para os termos seguintes
    numerador += 2
    denominador *= 2
    sinal *= -1

print(f'S = {S:.4f}')