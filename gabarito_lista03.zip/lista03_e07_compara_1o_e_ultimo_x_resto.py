# lista03.07 verif. se primeiro e ultimo são iguais e o resto diferente do 1o e ultimo

# lista exemplo
# (mas seu programa tem que funcionar p/ qq lista de qq tamanho)
w = ['ENCE', 'UFF', 'UERJ', 'ENCE']        # exemplo positivo
#w = ['ENCE', 'UFF', 'ENCE', 'ENCE']       # exemplo negativo

n = len(w)

# lista precisa ter ao menos 3 elementos...
if n < 3:
    print(w, '-> Não')
else:
    pri = w[0]       # pega o primeiro
    ult = w[-1]      # pega o ultimo
    
    if pri != ult:
        print(w, '-> Não')
        
    else: # só entrará aqui se primeiro é igual ao último
          # e lista tem pelo menos 3 elementos       

        ok = True # assume que é verdade
        for i in range(1,n-1): # faz o loop de 1 ao penúltimo
            if w[i] == pri:
                ok = False
                break

        if ok: print(w, '-> Sim')
        else: print(w, ' -> Não')
