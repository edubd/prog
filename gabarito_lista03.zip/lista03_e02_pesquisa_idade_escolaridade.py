# lista03.02 pesquisa idade x escolaridade 

# define os contadores necessários:
tot_pessoas = 0 # total de pessoas
tot_sup = 0     # total de pessoas com nível superior
soma_idade = 0  # soma das idades

while True:
    print(f'digite os dados do informante {tot_pessoas + 1}')
    e = input('Escolaridade (S=Superior ou N=Não possui superior): ')
    i = int(input('Idade: '))
    
    if i > 0 and e in ['S', 'N']: # processa a entrada apenas se for válida
        tot_pessoas += 1
        soma_idade += i
        if e == 'S': tot_sup += 1
    
    if i == -1: break

print('\n\nResultados:')
if tot_pessoas > 0:
    print(f'Média da idade: {soma_idade/tot_pessoas}')
    print(f'Total de pessoas com nível superior: {tot_sup}')
    print(f'Total de pessoas sem nível superior: {tot_pessoas - tot_sup}')
    
        
    
    
