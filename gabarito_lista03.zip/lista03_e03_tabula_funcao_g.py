# lista03.03 tabula função
for x in range(101):
    for y in range(6):
        if x == 0 and y == 0:
            g = 0
        else:
            g = (x**2 - y**2) / (x**2 + y**2)
        
        print(f'g({x},{y}) = {g:>10.8f}')