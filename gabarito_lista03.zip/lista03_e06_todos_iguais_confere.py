# lista03.06 verif. se todos os elementos da lista são iguais

# lista exemplo
# (mas seu programa tem que funcionar p/ qq lista de qq tamanho)
w = ['ENCE', 'ENCE', 'ENCE']        # exemplo positivo
#w = ['ENCE', 'UFF', 'ENCE', 'ENCE'] # exemplo negativo

# ---- aqui começa o que foi pedido no enunciado ----
n = len(w)

iguais = True # parte da hipótese de que são todos iguais

for i in range(n-1): # compara cada par. Havendo divergência quebra a hipótese
    if w[i] != w[i+1]:
        iguais = False
        break

if iguais: print(w, '-> Todos são iguais')
else: print(w, '-> Nem todos são iguais')